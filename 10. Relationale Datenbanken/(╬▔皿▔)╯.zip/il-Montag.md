1. 
Highlightet = Primary Key
Da die Spalte Futterarten wahrscheinlich den Datentyp varchar oder text hat befindet sich diese Tabelle in der ersten Normalform, soll der Text aber auch aufgeteilt werden dann könnte die Tabelle wie folgt aussehen:


| ==Tier-ID== | Tierart | Lebensraum | ==Futterart== |
| ----------- | ------- | ---------- | ------------- |
| 1           | Löwe    | Savanne    | Fleisch       |
| 1           | Löwe    | Savanne    | Knochen       |
| 2           | Papagei | Tropenwald | Früchte       |
| 2           | Papagei | Tropenwald | Samen         |
| 2           | Papagei | Tropenwald | Nüsse         |
| 3           | Hai     | Ozean      | Fische        |
| 3           | Hai     | Ozean      | Krebse        |
| 3           | Hai     | Ozean      | Tintenfische  |


2. 


| Veranstaltungs ID | VerantstaltungsName  | VeranstaltungsDatum | ==Teilnehmer ID== | Teilnehmer Namen |
| ----------------- | -------------------- | ------------------- | ----------------- | ---------------- |
| 101               | Musikfestival        | 2025-06-15          | 501               | Anna             |
| 101               | Musikfestival        | 2025-06-15          | 502               | Ben              |
| 101               | Musikfestival        | 2025-06-15          | 503               | Clara            |
| 102               | Technologiekonferenz | 2025-07-10          | 504               | Daniel           |
| 102               | Technologiekonferenz | 2025-07-10          | 505               | Emma             |
3. Die Tabelle befindet sich in der zweiten Normalform wenn die Teilnehmer ID als primary Key verwendet wird, ansonsten nicht.  

4. 

Tabelle Veranstaltung

| ==VeranstaltungsID== | VeranstaltungsName   | Veranstaltungsdatum |
| -------------------- | -------------------- | ------------------- |
| 101                  | Musikfestival        | 2025-06-15          |
| 102                  | Technologiekonferenz | 2025-07-10          |
Tabelle Personen

| ==TeilnehmerID== | Teilnehmer Namen | Veranstaltung ID |
| ---------------- | ---------------- | :--------------: |
| 501              | Anna             |       101        |
| 502              | Ben              |       101        |
| 503              | Clara            |       101        |
| 504              | Daniel           |       501        |
| 505              | Emma             |       501        |

5. 
**FahrerNr → Name, Vorname**  
**Fahrgestellnummer → Autohersteller, Automodell, 
Automodell → Hoechstgeschwindigkeit**    
**KFZ-Kennzeichen → FahrerNr

	
